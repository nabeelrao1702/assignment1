export const DARK_MODE = "DARK_MODE";
